import React from 'react';
import Header from './Header';
import Sidebar from './Sidebar';
import RightSidebar from './RightSidebar';
import { User } from '../../types';

interface LayoutProps {
  user: User;
  children: React.ReactNode;
  onLogout: () => void;
}

const Layout: React.FC<LayoutProps> = ({ user, children, onLogout }) => {
  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      <Header user={user} onLogout={onLogout} />
      <div className="flex">
        <Sidebar user={user} />
        <main className="flex-1 min-h-screen">
          {children}
        </main>
        <RightSidebar />
      </div>
    </div>
  );
};

export default Layout;