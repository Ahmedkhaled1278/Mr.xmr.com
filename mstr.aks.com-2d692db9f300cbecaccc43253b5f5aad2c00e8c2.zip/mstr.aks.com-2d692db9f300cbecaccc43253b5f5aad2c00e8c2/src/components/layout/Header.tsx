import React, { useState } from 'react';
import { Search, Home, Users, MessageCircle, Bell, Menu, Plus, User, Settings } from 'lucide-react';
import Avatar from '../ui/Avatar';
import Button from '../ui/Button';
import Modal from '../ui/Modal';
import { User as UserType } from '../../types';

interface HeaderProps {
  user: UserType;
  onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ user, onLogout }) => {
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const notifications = [
    { id: 1, type: 'like', message: 'أعجب أحمد بمنشورك', time: 'منذ 5 دقائق', read: false },
    { id: 2, type: 'comment', message: 'علقت فاطمة على منشورك', time: 'منذ 10 دقائق', read: false },
    { id: 3, type: 'friend_request', message: 'طلب صداقة من محمد', time: 'منذ ساعة', read: true },
  ];

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <>
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo and Search */}
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                <h1 className="text-2xl font-bold text-blue-600">Mr.X</h1>
              </div>
              <div className="hidden md:block">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="text"
                    placeholder="البحث في Mr.X"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-gray-100 rounded-full pl-10 pr-4 py-2 w-64 text-sm focus:outline-none focus:bg-white focus:shadow-md transition-all"
                  />
                </div>
              </div>
            </div>

            {/* Navigation Icons */}
            <div className="flex items-center space-x-2">
              <nav className="hidden md:flex items-center space-x-2">
                <Button variant="ghost" size="sm">
                  <Home className="w-6 h-6 text-blue-600" />
                </Button>
                <Button variant="ghost" size="sm" className="relative">
                  <Users className="w-6 h-6 text-gray-600" />
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">3</span>
                </Button>
                <Button variant="ghost" size="sm" className="relative">
                  <MessageCircle className="w-6 h-6 text-gray-600" />
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">5</span>
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="relative"
                  onClick={() => setShowNotifications(true)}
                >
                  <Bell className="w-6 h-6 text-gray-600" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                      {unreadCount}
                    </span>
                  )}
                </Button>
              </nav>

              {/* User Menu */}
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="sm">
                  <Plus className="w-5 h-5 text-gray-600" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Menu className="w-5 h-5 text-gray-600" />
                </Button>
                <div className="relative">
                  <button 
                    onClick={() => setShowUserMenu(!showUserMenu)}
                    className="flex items-center space-x-2 p-1 rounded-full hover:bg-gray-100 transition-colors"
                  >
                    <Avatar
                      fallback={user.name.charAt(0)}
                      online={user.isOnline}
                      size="sm"
                    />
                  </button>
                  
                  {showUserMenu && (
                    <div className="absolute left-0 mt-2 w-64 bg-white rounded-lg shadow-lg border z-50">
                      <div className="p-4">
                        <div className="flex items-center space-x-3 p-2 hover:bg-gray-100 rounded-lg cursor-pointer">
                          <Avatar
                            fallback={user.name.charAt(0)}
                            online={user.isOnline}
                            size="md"
                          />
                          <div>
                            <h3 className="font-medium">{user.name}</h3>
                            <p className="text-sm text-gray-500">عرض الملف الشخصي</p>
                          </div>
                        </div>
                        <hr className="my-2" />
                        <button className="w-full text-right p-2 hover:bg-gray-100 rounded-lg text-gray-700 flex items-center space-x-2">
                          <Settings className="w-4 h-4" />
                          <span>الإعدادات والخصوصية</span>
                        </button>
                        <button 
                          onClick={onLogout}
                          className="w-full text-right p-2 hover:bg-gray-100 rounded-lg text-gray-700"
                        >
                          تسجيل الخروج
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Notifications Modal */}
      <Modal
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
        title="الإشعارات"
        size="md"
      >
        <div className="p-4">
          {notifications.length === 0 ? (
            <p className="text-center text-gray-500 py-8">لا توجد إشعارات جديدة</p>
          ) : (
            <div className="space-y-3">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-3 rounded-lg cursor-pointer transition-colors ${
                    notification.read ? 'bg-gray-50' : 'bg-blue-50 border border-blue-200'
                  }`}
                >
                  <p className="text-sm text-gray-900">{notification.message}</p>
                  <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </Modal>
    </>
  );
};

export default Header;