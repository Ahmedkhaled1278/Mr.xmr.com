import React, { useState } from 'react';
import { 
  MessageCircle, Phone, Video, MoreHorizontal, Users, 
  Calendar, TrendingUp, Gift, Clock, MapPin 
} from 'lucide-react';
import Avatar from '../ui/Avatar';
import Button from '../ui/Button';
import { SAMPLE_USERS } from '../../utils/constants';

const RightSidebar: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'contacts' | 'groups' | 'events'>('contacts');

  const contacts = SAMPLE_USERS.map(user => ({
    ...user,
    status: user.isOnline ? 'متصل' : `متصل منذ ${Math.floor(Math.random() * 60)} دقيقة`,
  }));

  const groupChats = [
    { id: 1, name: 'فريق العمل', members: 12, lastMessage: 'أحمد: مرحباً بالجميع', avatar: 'F', online: 8 },
    { id: 2, name: 'العائلة', members: 8, lastMessage: 'فاطمة: كيف حالكم؟', avatar: 'E', online: 3 },
    { id: 3, name: 'الأصدقاء', members: 15, lastMessage: 'محمد: هل نلتقي اليوم؟', avatar: 'A', online: 12 },
    { id: 4, name: 'مجموعة الدراسة', members: 6, lastMessage: 'سارة: لا تنسوا الامتحان غداً', avatar: 'M', online: 2 },
  ];

  const events = [
    { 
      id: 1, 
      title: 'اجتماع الفريق', 
      time: '2:00 PM', 
      date: 'اليوم',
      attendees: 12,
      type: 'work'
    },
    { 
      id: 2, 
      title: 'عيد ميلاد أحمد', 
      time: '6:00 PM', 
      date: 'غداً',
      attendees: 25,
      type: 'birthday'
    },
    { 
      id: 3, 
      title: 'ورشة التطوير', 
      time: '10:00 AM', 
      date: 'الأحد',
      attendees: 50,
      type: 'workshop'
    },
  ];

  const trending = [
    { tag: '#مستر_إكس', posts: '1.2K منشور', growth: '+15%' },
    { tag: '#التقنية', posts: '856 منشور', growth: '+8%' },
    { tag: '#الإبداع', posts: '642 منشور', growth: '+12%' },
    { tag: '#البرمجة', posts: '423 منشور', growth: '+5%' },
    { tag: '#التصميم', posts: '389 منشور', growth: '+20%' },
  ];

  const birthdays = [
    { name: 'أحمد محمد', avatar: 'A', age: 25 },
    { name: 'فاطمة علي', avatar: 'F', age: 28 },
  ];

  return (
    <div className="w-80 bg-white h-screen overflow-y-auto border-r border-gray-200">
      <div className="p-4 space-y-6">
        {/* Tabs */}
        <div className="flex space-x-1 bg-gray-100 rounded-lg p-1">
          <button
            onClick={() => setActiveTab('contacts')}
            className={`flex-1 py-2 px-3 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'contacts' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-600'
            }`}
          >
            جهات الاتصال
          </button>
          <button
            onClick={() => setActiveTab('groups')}
            className={`flex-1 py-2 px-3 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'groups' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-600'
            }`}
          >
            المجموعات
          </button>
          <button
            onClick={() => setActiveTab('events')}
            className={`flex-1 py-2 px-3 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'events' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-600'
            }`}
          >
            الأحداث
          </button>
        </div>

        {/* Birthdays */}
        {birthdays.length > 0 && (
          <div className="bg-gradient-to-r from-pink-50 to-purple-50 rounded-lg p-4 border border-pink-200">
            <div className="flex items-center space-x-2 mb-3">
              <Gift className="w-5 h-5 text-pink-600" />
              <h3 className="font-semibold text-pink-900">أعياد الميلاد</h3>
            </div>
            <div className="space-y-2">
              {birthdays.map((person, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <Avatar fallback={person.avatar} size="sm" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-pink-900">
                      عيد ميلاد {person.name}
                    </p>
                    <p className="text-xs text-pink-700">يبلغ {person.age} عاماً اليوم</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Content based on active tab */}
        {activeTab === 'contacts' && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-gray-900">جهات الاتصال ({contacts.length})</h3>
              <button className="text-gray-500 hover:text-gray-700">
                <MoreHorizontal className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-2">
              {contacts.map((contact) => (
                <div key={contact.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors">
                  <div className="flex items-center space-x-3">
                    <Avatar
                      fallback={contact.avatar}
                      online={contact.isOnline}
                      size="sm"
                    />
                    <div>
                      <p className="text-sm font-medium text-gray-900">{contact.name}</p>
                      <p className="text-xs text-gray-500">{contact.status}</p>
                    </div>
                  </div>
                  <div className="flex space-x-1">
                    <Button variant="ghost" size="sm">
                      <MessageCircle className="w-4 h-4 text-gray-600" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Phone className="w-4 h-4 text-gray-600" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Video className="w-4 h-4 text-gray-600" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'groups' && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-gray-900">المحادثات الجماعية</h3>
              <Users className="w-4 h-4 text-gray-500" />
            </div>
            <div className="space-y-2">
              {groupChats.map((group) => (
                <div key={group.id} className="p-3 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <Avatar fallback={group.avatar} size="sm" />
                      <h4 className="font-medium text-gray-900">{group.name}</h4>
                    </div>
                    <div className="flex items-center space-x-1 text-xs text-gray-500">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>{group.online}</span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 truncate">{group.lastMessage}</p>
                  <p className="text-xs text-gray-500 mt-1">{group.members} عضو</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'events' && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-gray-900">الأحداث القادمة</h3>
              <Calendar className="w-4 h-4 text-gray-500" />
            </div>
            <div className="space-y-2">
              {events.map((event) => (
                <div key={event.id} className="p-3 rounded-lg bg-blue-50 border border-blue-200 hover:bg-blue-100 cursor-pointer transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-medium text-blue-900">{event.title}</h4>
                      <div className="flex items-center space-x-2 mt-1 text-sm text-blue-700">
                        <Clock className="w-3 h-3" />
                        <span>{event.date} - {event.time}</span>
                      </div>
                      <div className="flex items-center space-x-2 mt-1 text-xs text-blue-600">
                        <Users className="w-3 h-3" />
                        <span>{event.attendees} مشارك</span>
                      </div>
                    </div>
                    {event.type === 'birthday' && <Gift className="w-4 h-4 text-pink-500" />}
                    {event.type === 'work' && <MapPin className="w-4 h-4 text-blue-500" />}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Trending */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-gray-900">الأكثر رواجاً</h3>
            <TrendingUp className="w-4 h-4 text-gray-500" />
          </div>
          <div className="space-y-2">
            {trending.map((trend, index) => (
              <div key={index} className="p-2 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium text-blue-600">{trend.tag}</h4>
                  <span className="text-xs text-green-600 font-medium">{trend.growth}</span>
                </div>
                <p className="text-sm text-gray-500">{trend.posts}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-gray-50 rounded-lg p-4">
          <h3 className="font-semibold text-gray-900 mb-3">إجراءات سريعة</h3>
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" size="sm" fullWidth>
              <Users className="w-4 h-4" />
              إنشاء مجموعة
            </Button>
            <Button variant="outline" size="sm" fullWidth>
              <Calendar className="w-4 h-4" />
              إنشاء حدث
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RightSidebar;