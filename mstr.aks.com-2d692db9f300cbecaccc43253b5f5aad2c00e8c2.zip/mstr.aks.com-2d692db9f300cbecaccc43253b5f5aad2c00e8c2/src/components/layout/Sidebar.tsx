import React from 'react';
import { 
  Home, Users, Bookmark, Clock, Calendar, Heart, Star, 
  Zap, MapPin, MessageSquare, Video, Image, Music, 
  ShoppingBag, Gamepad2, TrendingUp 
} from 'lucide-react';
import Avatar from '../ui/Avatar';
import { User } from '../../types';

interface SidebarProps {
  user: User;
}

const Sidebar: React.FC<SidebarProps> = ({ user }) => {
  const mainMenuItems = [
    { icon: Home, label: 'الصفحة الرئيسية', active: true, href: '/' },
    { icon: Users, label: 'الأصدقاء', count: user.friendsCount, href: '/friends' },
    { icon: MessageSquare, label: 'المجموعات', count: 12, href: '/groups' },
    { icon: Video, label: 'Watch', href: '/watch' },
    { icon: Bookmark, label: 'المحفوظات', href: '/saved' },
    { icon: Clock, label: 'الذكريات', href: '/memories' },
    { icon: Calendar, label: 'الأحداث', href: '/events' },
    { icon: Heart, label: 'المفضلة', href: '/favorites' },
    { icon: Star, label: 'الصفحات', count: 45, href: '/pages' },
    { icon: Image, label: 'الصور', href: '/photos' },
    { icon: Music, label: 'الموسيقى', href: '/music' },
    { icon: ShoppingBag, label: 'Marketplace', href: '/marketplace' },
    { icon: Gamepad2, label: 'الألعاب', href: '/games' },
    { icon: TrendingUp, label: 'الأكثر رواجاً', href: '/trending' },
  ];

  const uniqueFeatures = [
    { icon: Zap, label: 'لقاءات عشوائية', color: 'text-purple-600', href: '/random-meetings' },
    { icon: Clock, label: 'رسائل زمنية', color: 'text-green-600', href: '/timed-messages' },
    { icon: MessageSquare, label: 'غرف البوح', color: 'text-red-600', href: '/confession-rooms' },
    { icon: MapPin, label: 'الخرائط الزمنية', color: 'text-blue-600', href: '/time-maps' },
  ];

  const shortcuts = [
    { name: 'مجموعة المطورين', color: 'from-purple-500 to-pink-500', members: 1234 },
    { name: 'نادي الإبداع', color: 'from-green-500 to-blue-500', members: 567 },
    { name: 'مجتمع التقنية', color: 'from-orange-500 to-red-500', members: 890 },
    { name: 'عشاق الفن', color: 'from-indigo-500 to-purple-500', members: 456 },
  ];

  return (
    <div className="w-80 bg-white h-screen overflow-y-auto border-l border-gray-200 scrollbar-thin scrollbar-thumb-gray-300">
      <div className="p-4">
        {/* User Profile */}
        <div className="flex items-center space-x-3 p-3 hover:bg-gray-100 rounded-lg cursor-pointer mb-4 transition-colors">
          <Avatar
            fallback={user.name.charAt(0)}
            online={user.isOnline}
            size="md"
          />
          <div>
            <h3 className="font-semibold text-gray-900">{user.name}</h3>
            <p className="text-sm text-gray-500">عرض الملف الشخصي</p>
          </div>
        </div>

        {/* Main Menu */}
        <div className="space-y-1 mb-6">
          {mainMenuItems.map((item, index) => (
            <div
              key={index}
              className={`flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors ${
                item.active ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100'
              }`}
            >
              <div className="flex items-center space-x-3">
                <item.icon className={`w-5 h-5 ${item.active ? 'text-blue-600' : 'text-gray-600'}`} />
                <span className={`font-medium ${item.active ? 'text-blue-600' : 'text-gray-900'}`}>
                  {item.label}
                </span>
              </div>
              {item.count && (
                <span className="bg-gray-200 text-gray-700 text-xs px-2 py-1 rounded-full">
                  {item.count.toLocaleString()}
                </span>
              )}
            </div>
          ))}
        </div>

        {/* Unique Features Section */}
        <div className="border-t border-gray-200 pt-4">
          <h4 className="font-semibold text-gray-900 mb-3 px-3">ميزات Mr.X الفريدة</h4>
          <div className="space-y-1">
            {uniqueFeatures.map((feature, index) => (
              <div
                key={index}
                className="flex items-center space-x-3 p-3 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors"
              >
                <feature.icon className={`w-5 h-5 ${feature.color}`} />
                <span className="font-medium text-gray-900">{feature.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Shortcuts */}
        <div className="border-t border-gray-200 pt-4 mt-4">
          <h4 className="font-semibold text-gray-900 mb-3 px-3">اختصارات المجموعات</h4>
          <div className="space-y-2">
            {shortcuts.map((shortcut, index) => (
              <div key={index} className="flex items-center space-x-3 p-2 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
                <div className={`w-8 h-8 bg-gradient-to-r ${shortcut.color} rounded-lg`}></div>
                <div className="flex-1">
                  <span className="text-sm font-medium text-gray-900">{shortcut.name}</span>
                  <p className="text-xs text-gray-500">{shortcut.members.toLocaleString()} عضو</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-gray-200 pt-4 mt-6">
          <div className="text-xs text-gray-500 space-y-1">
            <p>الخصوصية · الشروط · الإعلانات · خيارات الإعلانات</p>
            <p>ملفات تعريف الارتباط · المزيد · Mr.X © 2025</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;