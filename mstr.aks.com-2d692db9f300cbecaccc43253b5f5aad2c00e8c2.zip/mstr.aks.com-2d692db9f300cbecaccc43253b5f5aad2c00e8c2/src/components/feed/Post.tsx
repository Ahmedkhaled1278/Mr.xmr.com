import React, { useState } from 'react';
import { 
  Heart, MessageCircle, Share, MoreHorizontal, Clock, Zap, Eye, 
  Bookmark, Send, ThumbsUp, Smile 
} from 'lucide-react';
import { motion } from 'framer-motion';
import Avatar from '../ui/Avatar';
import Button from '../ui/Button';
import { Post as PostType, Comment } from '../../types';
import { formatTimeAgo } from '../../utils/dateUtils';

interface PostProps {
  post: PostType;
  onLike: (postId: string) => void;
  onBookmark: (postId: string) => void;
}

const Post: React.FC<PostProps> = ({ post, onLike, onBookmark }) => {
  const [showComments, setShowComments] = useState(false);
  const [comment, setComment] = useState('');
  const [showFullContent, setShowFullContent] = useState(false);

  const handleComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (comment.trim()) {
      setComment('');
      setShowComments(true);
    }
  };

  const getPostTypeIcon = () => {
    switch (post.type) {
      case 'timed':
        return <Clock className="w-4 h-4 text-green-600" />;
      case 'anonymous':
        return <Eye className="w-4 h-4 text-red-600" />;
      case 'challenge':
        return <Zap className="w-4 h-4 text-purple-600" />;
      default:
        return null;
    }
  };

  const getPostTypeLabel = () => {
    switch (post.type) {
      case 'timed':
        return 'رسالة زمنية';
      case 'anonymous':
        return 'بوح مجهول';
      case 'challenge':
        return 'تحدي إبداعي';
      default:
        return null;
    }
  };

  const shouldTruncateContent = post.content.length > 300;
  const displayContent = shouldTruncateContent && !showFullContent 
    ? post.content.substring(0, 300) + '...' 
    : post.content;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-lg shadow-sm border border-gray-200 mb-4"
    >
      {/* Post Header */}
      <div className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Avatar
              fallback={post.type === 'anonymous' ? '؟' : post.author.name.charAt(0)}
              online={post.author.isOnline}
              size="md"
            />
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="font-semibold text-gray-900">
                  {post.type === 'anonymous' ? 'مجهول' : post.author.name}
                </h3>
                {getPostTypeIcon() && (
                  <div className="flex items-center space-x-1">
                    {getPostTypeIcon()}
                    <span className="text-sm text-gray-600">{getPostTypeLabel()}</span>
                  </div>
                )}
              </div>
              <p className="text-sm text-gray-500">{formatTimeAgo(post.timestamp)}</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onBookmark(post.id)}
              className={post.isBookmarked ? 'text-blue-600' : 'text-gray-600'}
            >
              <Bookmark className={`w-5 h-5 ${post.isBookmarked ? 'fill-current' : ''}`} />
            </Button>
            <Button variant="ghost" size="sm">
              <MoreHorizontal className="w-5 h-5 text-gray-600" />
            </Button>
          </div>
        </div>
      </div>

      {/* Post Content */}
      <div className="px-4 pb-3">
        <p className="text-gray-900 leading-relaxed whitespace-pre-wrap">
          {displayContent}
        </p>
        {shouldTruncateContent && (
          <button
            onClick={() => setShowFullContent(!showFullContent)}
            className="text-blue-600 hover:text-blue-700 text-sm font-medium mt-2"
          >
            {showFullContent ? 'عرض أقل' : 'عرض المزيد'}
          </button>
        )}
      </div>

      {/* Post Stats */}
      {(post.likes > 0 || post.comments.length > 0 || post.shares > 0) && (
        <div className="px-4 py-2 border-t border-gray-100">
          <div className="flex items-center justify-between text-sm text-gray-500">
            <div className="flex items-center space-x-4">
              {post.likes > 0 && (
                <span className="flex items-center space-x-1">
                  <div className="flex -space-x-1">
                    <div className="w-5 h-5 bg-blue-600 rounded-full flex items-center justify-center">
                      <ThumbsUp className="w-3 h-3 text-white" />
                    </div>
                    <div className="w-5 h-5 bg-red-600 rounded-full flex items-center justify-center">
                      <Heart className="w-3 h-3 text-white fill-current" />
                    </div>
                  </div>
                  <span>{post.likes.toLocaleString()}</span>
                </span>
              )}
            </div>
            <div className="flex items-center space-x-4">
              {post.comments.length > 0 && (
                <span>{post.comments.length} تعليق</span>
              )}
              {post.shares > 0 && (
                <span>{post.shares} مشاركة</span>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Post Actions */}
      <div className="border-t border-gray-200">
        <div className="flex items-center justify-between px-4 py-2">
          <div className="flex items-center space-x-1 w-full">
            <Button
              onClick={() => onLike(post.id)}
              variant="ghost"
              size="sm"
              fullWidth
              className={`flex items-center justify-center space-x-2 ${
                post.isLiked ? 'text-blue-600' : 'text-gray-600'
              }`}
            >
              <ThumbsUp className={`w-5 h-5 ${post.isLiked ? 'fill-current' : ''}`} />
              <span className="text-sm font-medium">إعجاب</span>
            </Button>
            <Button
              onClick={() => setShowComments(!showComments)}
              variant="ghost"
              size="sm"
              fullWidth
              className="flex items-center justify-center space-x-2 text-gray-600"
            >
              <MessageCircle className="w-5 h-5" />
              <span className="text-sm font-medium">تعليق</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              fullWidth
              className="flex items-center justify-center space-x-2 text-gray-600"
            >
              <Share className="w-5 h-5" />
              <span className="text-sm font-medium">مشاركة</span>
            </Button>
          </div>
        </div>

        {/* Comments Section */}
        {showComments && (
          <div className="border-t border-gray-200 p-4">
            <form onSubmit={handleComment} className="flex items-center space-x-3 mb-4">
              <Avatar fallback="أ" size="sm" />
              <div className="flex-1 flex items-center space-x-2">
                <input
                  type="text"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="اكتب تعليقاً..."
                  className="flex-1 p-2 bg-gray-100 rounded-full outline-none focus:bg-white focus:shadow-md transition-all"
                />
                <Button
                  type="submit"
                  variant="ghost"
                  size="sm"
                  disabled={!comment.trim()}
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </form>
            
            {/* Sample Comments */}
            <div className="space-y-3">
              {post.comments.map((comment) => (
                <div key={comment.id} className="flex items-start space-x-3">
                  <Avatar fallback={comment.author.name.charAt(0)} size="sm" />
                  <div className="flex-1">
                    <div className="bg-gray-100 rounded-lg p-3">
                      <h4 className="font-medium text-gray-900">{comment.author.name}</h4>
                      <p className="text-gray-700">{comment.content}</p>
                    </div>
                    <div className="flex items-center space-x-4 mt-1 text-sm text-gray-500">
                      <button className="hover:text-blue-600 font-medium">إعجاب</button>
                      <button className="hover:text-blue-600 font-medium">رد</button>
                      <span>{formatTimeAgo(comment.timestamp)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default Post;