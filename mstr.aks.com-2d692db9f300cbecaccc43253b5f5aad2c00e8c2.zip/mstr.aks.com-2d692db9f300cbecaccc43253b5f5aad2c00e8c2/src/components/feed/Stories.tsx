import React, { useState } from 'react';
import { Plus, Play, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Avatar from '../ui/Avatar';
import Modal from '../ui/Modal';
import { User, Story } from '../../types';
import { SAMPLE_USERS } from '../../utils/constants';

interface StoriesProps {
  user: User;
}

const Stories: React.FC<StoriesProps> = ({ user }) => {
  const [selectedStory, setSelectedStory] = useState<Story | null>(null);
  const [showCreateStory, setShowCreateStory] = useState(false);

  const stories: Story[] = [
    {
      id: '1',
      author: SAMPLE_USERS[0],
      content: 'قصة رائعة من أحمد!',
      type: 'text',
      timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
      expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24).toISOString(),
      viewers: [],
      isViewed: false,
    },
    {
      id: '2',
      author: SAMPLE_USERS[1],
      content: 'يوم جميل في دبي',
      type: 'text',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
      expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 22).toISOString(),
      viewers: [],
      isViewed: true,
    },
    {
      id: '3',
      author: SAMPLE_USERS[2],
      content: 'مشروع جديد قادم قريباً!',
      type: 'text',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 4).toISOString(),
      expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 20).toISOString(),
      viewers: [],
      isViewed: false,
    },
  ];

  return (
    <>
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-4">
        <div className="flex space-x-4 overflow-x-auto pb-2 scrollbar-hide">
          {/* Add Story */}
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex-shrink-0 text-center cursor-pointer"
            onClick={() => setShowCreateStory(true)}
          >
            <div className="relative w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mb-2 hover:bg-gray-300 transition-colors">
              <Avatar fallback={user.name.charAt(0)} size="md" />
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center border-2 border-white">
                <Plus className="w-3 h-3 text-white" />
              </div>
            </div>
            <p className="text-xs text-gray-600 font-medium">إنشاء قصة</p>
          </motion.div>

          {/* Stories */}
          {stories.map((story) => (
            <motion.div
              key={story.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="flex-shrink-0 text-center cursor-pointer"
              onClick={() => setSelectedStory(story)}
            >
              <div className={`relative w-16 h-16 rounded-full p-1 mb-2 ${
                story.isViewed 
                  ? 'bg-gray-300' 
                  : 'bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500'
              }`}>
                <div className="w-full h-full bg-white rounded-full p-1">
                  <Avatar fallback={story.author.name.charAt(0)} size="sm" />
                </div>
                <div className="absolute bottom-0 right-0 w-5 h-5 bg-green-500 rounded-full border-2 border-white flex items-center justify-center">
                  <Play className="w-2 h-2 text-white fill-current" />
                </div>
              </div>
              <p className="text-xs text-gray-600 font-medium truncate w-16">
                {story.author.name.split(' ')[0]}
              </p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Story Viewer Modal */}
      <Modal
        isOpen={!!selectedStory}
        onClose={() => setSelectedStory(null)}
        size="lg"
        showCloseButton={false}
      >
        {selectedStory && (
          <div className="relative bg-black text-white min-h-[500px] flex flex-col">
            {/* Story Header */}
            <div className="flex items-center justify-between p-4 bg-gradient-to-b from-black/50 to-transparent">
              <div className="flex items-center space-x-3">
                <Avatar fallback={selectedStory.author.name.charAt(0)} size="sm" />
                <div>
                  <h3 className="font-medium">{selectedStory.author.name}</h3>
                  <p className="text-sm text-gray-300">منذ ساعتين</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedStory(null)}
                className="p-2 rounded-full bg-black/30 hover:bg-black/50 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Story Content */}
            <div className="flex-1 flex items-center justify-center p-8">
              <div className="text-center">
                <h2 className="text-2xl font-bold mb-4">{selectedStory.content}</h2>
                <p className="text-gray-300">هذه قصة نصية من {selectedStory.author.name}</p>
              </div>
            </div>

            {/* Story Progress Bar */}
            <div className="absolute top-2 left-4 right-4">
              <div className="h-1 bg-white/30 rounded-full">
                <motion.div
                  className="h-full bg-white rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: '100%' }}
                  transition={{ duration: 5 }}
                />
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* Create Story Modal */}
      <Modal
        isOpen={showCreateStory}
        onClose={() => setShowCreateStory(false)}
        title="إنشاء قصة جديدة"
        size="md"
      >
        <div className="p-6">
          <div className="text-center">
            <div className="w-24 h-24 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center">
              <Plus className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold mb-2">أضف إلى قصتك</h3>
            <p className="text-gray-600 mb-6">شارك لحظة من يومك مع أصدقائك</p>
            
            <div className="grid grid-cols-2 gap-4">
              <button className="p-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                <div className="w-8 h-8 bg-blue-100 rounded-full mx-auto mb-2 flex items-center justify-center">
                  <span className="text-blue-600 text-lg">📝</span>
                </div>
                <span className="text-sm font-medium">نص</span>
              </button>
              <button className="p-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                <div className="w-8 h-8 bg-green-100 rounded-full mx-auto mb-2 flex items-center justify-center">
                  <span className="text-green-600 text-lg">📷</span>
                </div>
                <span className="text-sm font-medium">صورة</span>
              </button>
            </div>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default Stories;