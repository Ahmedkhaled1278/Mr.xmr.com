import React, { useState, useCallback, useMemo } from 'react';
import { 
  Image, Video, Smile, MapPin, Tag, Calendar, Zap, Clock, 
  MessageSquare, Globe, Users, Lock, X
} from 'lucide-react';
import Button from '../ui/Button';
import Avatar from '../ui/Avatar';
import Modal from '../ui/Modal';
import { User, Post } from '../../types';
import { EMOTIONS, PRIVACY_OPTIONS, POST_TYPES } from '../../utils/constants';

interface CreatePostProps {
  user: User;
  onCreatePost: (post: Post) => void;
}

const CreatePost: React.FC<CreatePostProps> = ({ user, onCreatePost }) => {
  const [postText, setPostText] = useState('');
  const [postType, setPostType] = useState('normal');
  const [privacy, setPrivacy] = useState('public');
  const [selectedEmotion, setSelectedEmotion] = useState<string | null>(null);
  const [selectedLocation, setSelectedLocation] = useState<string | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Icon mapping for better performance
  const iconMap = useMemo(() => ({
    Clock,
    MessageSquare,
    Zap,
    Image: Image,
    Video,
    Calendar,
    Globe,
    Users,
    Lock
  }), []);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!postText.trim() || isSubmitting) return;

    setIsSubmitting(true);
    
    try {
      const newPost: Post = {
        id: Date.now().toString(),
        author: user,
        content: postText,
        type: postType as any,
        timestamp: new Date().toISOString(),
        likes: 0,
        comments: [],
        shares: 0,
        privacy: privacy as any,
        isLiked: false,
        isBookmarked: false,
      };
      
      // Simulate quick post creation
      await new Promise(resolve => setTimeout(resolve, 100));
      
      onCreatePost(newPost);
      
      // Reset form
      setPostText('');
      setPostType('normal');
      setSelectedEmotion(null);
      setSelectedLocation(null);
    } catch (error) {
      console.error('Error creating post:', error);
    } finally {
      setIsSubmitting(false);
    }
  }, [postText, postType, privacy, user, onCreatePost, isSubmitting]);

  const getPrivacyIcon = useCallback(() => {
    switch (privacy) {
      case 'public': return <Globe className="w-4 h-4" />;
      case 'friends': return <Users className="w-4 h-4" />;
      case 'private': return <Lock className="w-4 h-4" />;
      default: return <Globe className="w-4 h-4" />;
    }
  }, [privacy]);

  const selectedPrivacyOption = useMemo(() => 
    PRIVACY_OPTIONS.find(option => option.id === privacy),
    [privacy]
  );

  const handleEmotionSelect = useCallback((emotionId: string) => {
    setSelectedEmotion(emotionId);
    setShowEmojiPicker(false);
  }, []);

  const handlePrivacySelect = useCallback((privacyId: string) => {
    setPrivacy(privacyId);
    setShowPrivacyModal(false);
  }, []);

  return (
    <>
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-4">
        <div className="flex items-start space-x-3">
          <Avatar
            fallback={user.name.charAt(0)}
            online={user.isOnline}
            size="md"
          />
          <div className="flex-1">
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <textarea
                  value={postText}
                  onChange={(e) => setPostText(e.target.value)}
                  placeholder={`ما الذي تفكر فيه يا ${user.name}؟`}
                  className="w-full p-3 text-lg resize-none border-none outline-none bg-gray-50 rounded-lg focus:bg-white focus:shadow-md transition-all"
                  rows={3}
                  disabled={isSubmitting}
                />
              </div>

              {/* Selected Emotion */}
              {selectedEmotion && (
                <div className="mb-3 flex items-center space-x-2 text-sm text-gray-600">
                  <span>يشعر بـ</span>
                  <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                    {EMOTIONS.find(e => e.id === selectedEmotion)?.emoji} {EMOTIONS.find(e => e.id === selectedEmotion)?.label}
                  </span>
                  <button
                    type="button"
                    onClick={() => setSelectedEmotion(null)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* Selected Location */}
              {selectedLocation && (
                <div className="mb-3 flex items-center space-x-2 text-sm text-gray-600">
                  <MapPin className="w-4 h-4" />
                  <span>في {selectedLocation}</span>
                  <button
                    type="button"
                    onClick={() => setSelectedLocation(null)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
              
              {/* Post Type Selection */}
              <div className="flex flex-wrap gap-2 mb-3">
                {POST_TYPES.map((type) => {
                  const IconComponent = type.icon ? iconMap[type.icon as keyof typeof iconMap] : null;
                  return (
                    <button
                      key={type.id}
                      type="button"
                      onClick={() => setPostType(type.id)}
                      disabled={isSubmitting}
                      className={`flex items-center space-x-2 px-3 py-2 rounded-full text-sm font-medium transition-colors disabled:opacity-50 ${
                        postType === type.id
                          ? 'bg-blue-100 text-blue-600 border border-blue-300'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {IconComponent && (
                        <IconComponent className={`w-4 h-4 ${type.color}`} />
                      )}
                      <span>{type.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Privacy and Actions */}
              <div className="flex items-center justify-between pt-3 border-t border-gray-200">
                <div className="flex items-center space-x-2">
                  <div className="flex items-center space-x-4">
                    <Button variant="ghost" size="sm" type="button" disabled={isSubmitting}>
                      <Image className="w-5 h-5 text-green-600" />
                      <span className="text-sm font-medium">صورة/فيديو</span>
                    </Button>
                    <Button variant="ghost" size="sm" type="button" disabled={isSubmitting}>
                      <Tag className="w-5 h-5 text-blue-600" />
                      <span className="text-sm font-medium">تاج أصدقاء</span>
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      type="button"
                      onClick={() => setShowEmojiPicker(true)}
                      disabled={isSubmitting}
                    >
                      <Smile className="w-5 h-5 text-yellow-600" />
                      <span className="text-sm font-medium">مشاعر</span>
                    </Button>
                    <Button variant="ghost" size="sm" type="button" disabled={isSubmitting}>
                      <MapPin className="w-5 h-5 text-red-600" />
                      <span className="text-sm font-medium">موقع</span>
                    </Button>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    type="button"
                    onClick={() => setShowPrivacyModal(true)}
                    className="flex items-center space-x-2"
                    disabled={isSubmitting}
                  >
                    {getPrivacyIcon()}
                    <span className="text-sm">{selectedPrivacyOption?.label}</span>
                  </Button>
                  
                  <Button
                    type="submit"
                    disabled={!postText.trim() || isSubmitting}
                    variant="primary"
                    size="md"
                    loading={isSubmitting}
                  >
                    {isSubmitting ? 'جاري النشر...' : 'نشر'}
                  </Button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>

      {/* Emotion Picker Modal */}
      <Modal
        isOpen={showEmojiPicker}
        onClose={() => setShowEmojiPicker(false)}
        title="كيف تشعر؟"
        size="md"
      >
        <div className="p-4">
          <div className="grid grid-cols-2 gap-3">
            {EMOTIONS.map((emotion) => (
              <button
                key={emotion.id}
                onClick={() => handleEmotionSelect(emotion.id)}
                className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <span className="text-2xl">{emotion.emoji}</span>
                <span className={`font-medium ${emotion.color}`}>{emotion.label}</span>
              </button>
            ))}
          </div>
        </div>
      </Modal>

      {/* Privacy Modal */}
      <Modal
        isOpen={showPrivacyModal}
        onClose={() => setShowPrivacyModal(false)}
        title="اختر الجمهور"
        size="md"
      >
        <div className="p-4">
          <div className="space-y-3">
            {PRIVACY_OPTIONS.map((option) => (
              <button
                key={option.id}
                onClick={() => handlePrivacySelect(option.id)}
                className={`w-full flex items-center space-x-3 p-3 rounded-lg transition-colors ${
                  privacy === option.id ? 'bg-blue-50 border border-blue-200' : 'hover:bg-gray-100'
                }`}
              >
                <span className="text-2xl">{option.icon}</span>
                <div className="flex-1 text-right">
                  <h3 className="font-medium text-gray-900">{option.label}</h3>
                  <p className="text-sm text-gray-500">{option.description}</p>
                </div>
                {privacy === option.id && (
                  <div className="w-4 h-4 bg-blue-600 rounded-full"></div>
                )}
              </button>
            ))}
          </div>
        </div>
      </Modal>
    </>
  );
};

export default CreatePost;