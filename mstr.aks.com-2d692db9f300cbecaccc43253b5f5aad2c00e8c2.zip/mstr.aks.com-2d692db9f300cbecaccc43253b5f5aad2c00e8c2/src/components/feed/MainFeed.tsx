import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Stories from './Stories';
import CreatePost from './CreatePost';
import Post from './Post';
import { User, Post as PostType, Comment } from '../../types';
import { SAMPLE_USERS } from '../../utils/constants';

interface MainFeedProps {
  user: User;
}

const MainFeed: React.FC<MainFeedProps> = ({ user }) => {
  const [posts, setPosts] = useState<PostType[]>([
    {
      id: '1',
      author: SAMPLE_USERS[0],
      content: 'مرحباً بكم في Mr.X! منصة التواصل الاجتماعي الجديدة التي تجمع بين الخصوصية والإبداع. نحن متحمسون لرؤية ما ستشاركونه معنا! 🚀\n\nهذه المنصة تتميز بميزات فريدة مثل الرسائل الزمنية وغرف البوح المجهولة والتحديات الإبداعية. انضموا إلينا في هذه الرحلة المثيرة!',
      type: 'normal',
      timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
      likes: 24,
      comments: [
        {
          id: '1',
          author: SAMPLE_USERS[1],
          content: 'منصة رائعة! متحمسة للاستكشاف أكثر',
          timestamp: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
          likes: 5,
          isLiked: false,
        },
        {
          id: '2',
          author: SAMPLE_USERS[2],
          content: 'أخيراً منصة تهتم بالخصوصية! شكراً لكم',
          timestamp: new Date(Date.now() - 1000 * 60 * 10).toISOString(),
          likes: 3,
          isLiked: true,
        }
      ],
      shares: 3,
      privacy: 'public',
      isLiked: false,
      isBookmarked: false,
    },
    {
      id: '2',
      author: SAMPLE_USERS[1],
      content: 'تجربة الرسائل الزمنية في Mr.X رائعة! يمكنني الآن إرسال رسائل لنفسي في المستقبل. هذه الميزة ستغير طريقة تفكيرنا في التواصل. ⏰✨\n\nتخيلوا أن تتلقوا رسالة من أنفسكم بعد سنة تذكركم بأهدافكم وأحلامكم!',
      type: 'timed',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
      likes: 45,
      comments: [
        {
          id: '3',
          author: SAMPLE_USERS[0],
          content: 'فكرة عبقرية! سأجربها الآن',
          timestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
          likes: 2,
          isLiked: false,
        }
      ],
      shares: 7,
      privacy: 'public',
      isLiked: true,
      isBookmarked: false,
    },
    {
      id: '3',
      author: { ...SAMPLE_USERS[2], name: 'مجهول' },
      content: 'أحياناً نحتاج إلى مكان آمن للتعبير عن مشاعرنا دون خوف من الحكم. غرف البوح المجهولة في Mr.X توفر هذا المكان الآمن. 💭\n\nهنا يمكنكم مشاركة أعمق أفكاركم وأسراركم دون الكشف عن هويتكم. أحياناً الصراحة المجهولة تحرر الروح.',
      type: 'anonymous',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 4).toISOString(),
      likes: 67,
      comments: [
        {
          id: '4',
          author: { ...SAMPLE_USERS[1], name: 'مجهول' },
          content: 'شكراً لك على هذا المكان الآمن',
          timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
          likes: 8,
          isLiked: false,
        }
      ],
      shares: 15,
      privacy: 'public',
      isLiked: false,
      isBookmarked: true,
    },
    {
      id: '4',
      author: SAMPLE_USERS[2],
      content: 'تحدي إبداعي جديد: اكتب قصة قصيرة في 100 كلمة عن المستقبل! 🤔💡\n\nسأبدأ أنا: "في عام 2050، استيقظت لأجد أن الذكاء الاصطناعي قد حل جميع مشاكل العالم، لكنه نسي أن يحل مشكلة واحدة: كيف نجد المعنى في الحياة عندما تصبح مثالية؟ فقررت أن أبحث عن الإجابة في أبسط الأشياء: ابتسامة طفل، عناق صديق، وغروب الشمس."\n\nالآن دوركم! شاركوا قصصكم 📝',
      type: 'challenge',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 6).toISOString(),
      likes: 89,
      comments: [
        {
          id: '5',
          author: SAMPLE_USERS[0],
          content: 'تحدي رائع! سأشارك قصتي قريباً',
          timestamp: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
          likes: 4,
          isLiked: true,
        },
        {
          id: '6',
          author: SAMPLE_USERS[1],
          content: 'قصة جميلة ومؤثرة! أحب هذه التحديات الإبداعية',
          timestamp: new Date(Date.now() - 1000 * 60 * 150).toISOString(),
          likes: 6,
          isLiked: false,
        }
      ],
      shares: 21,
      privacy: 'public',
      isLiked: false,
      isBookmarked: false,
    }
  ]);

  const handleCreatePost = (newPost: PostType) => {
    setPosts([newPost, ...posts]);
  };

  const handleLikePost = (postId: string) => {
    setPosts(posts.map(post => 
      post.id === postId 
        ? { 
            ...post, 
            isLiked: !post.isLiked,
            likes: post.isLiked ? post.likes - 1 : post.likes + 1
          }
        : post
    ));
  };

  const handleBookmarkPost = (postId: string) => {
    setPosts(posts.map(post => 
      post.id === postId 
        ? { ...post, isBookmarked: !post.isBookmarked }
        : post
    ));
  };

  return (
    <div className="flex-1 max-w-2xl mx-auto p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Stories user={user} />
        <CreatePost user={user} onCreatePost={handleCreatePost} />
        
        <div className="space-y-4">
          {posts.map((post, index) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
            >
              <Post 
                post={post} 
                onLike={handleLikePost}
                onBookmark={handleBookmarkPost}
              />
            </motion.div>
          ))}
        </div>

        {/* Load More */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center py-8"
        >
          <button className="px-6 py-3 bg-gray-100 hover:bg-gray-200 rounded-lg text-gray-700 font-medium transition-colors hover:shadow-md">
            تحميل المزيد من المنشورات
          </button>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default MainFeed;