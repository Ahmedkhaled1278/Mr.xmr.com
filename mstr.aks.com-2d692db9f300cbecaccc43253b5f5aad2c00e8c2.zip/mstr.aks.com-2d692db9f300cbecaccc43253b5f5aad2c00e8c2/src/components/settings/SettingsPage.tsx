import React, { useState } from 'react';
import { 
  User, Lock, Bell, Eye, Globe, Shield, Palette, 
  Monitor, Smartphone, Download, Upload, Trash2, 
  Settings, Save, RefreshCw, AlertTriangle, Check,
  Moon, Sun, Languages, Volume2, Camera, MapPin,
  Heart, MessageCircle, Users, Calendar, Star
} from 'lucide-react';
import { motion } from 'framer-motion';
import Avatar from '../ui/Avatar';
import Button from '../ui/Button';
import Modal from '../ui/Modal';
import { User as UserType } from '../../types';
import { useAuth } from '../../hooks/useAuth';

interface SettingsPageProps {
  user: UserType;
  onClose: () => void;
}

const SettingsPage: React.FC<SettingsPageProps> = ({ user, onClose }) => {
  const { updateUser } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [settings, setSettings] = useState({
    // إعدادات الملف الشخصي
    profile: {
      name: user.name,
      bio: user.bio || '',
      location: user.location || '',
      website: user.website || '',
      showEmail: false,
      showPhone: false,
      showBirthday: true,
    },
    // إعدادات الخصوصية
    privacy: {
      profileVisibility: 'public',
      postsVisibility: 'friends',
      friendsListVisibility: 'friends',
      searchVisibility: true,
      messagePermissions: 'friends',
      tagPermissions: 'friends',
      storyVisibility: 'friends',
      onlineStatus: true,
    },
    // إعدادات الإشعارات
    notifications: {
      emailNotifications: true,
      pushNotifications: true,
      soundEnabled: true,
      likes: true,
      comments: true,
      shares: true,
      friendRequests: true,
      messages: true,
      mentions: true,
      birthdays: true,
      events: true,
      groupActivity: true,
    },
    // إعدادات الأمان
    security: {
      twoFactorAuth: false,
      loginAlerts: true,
      deviceTracking: true,
      sessionTimeout: 30,
      passwordStrength: 'strong',
      loginHistory: true,
    },
    // إعدادات المظهر
    appearance: {
      theme: 'light',
      language: 'ar',
      fontSize: 'medium',
      compactMode: false,
      animations: true,
      autoPlayVideos: true,
      showOnlineStatus: true,
    },
    // إعدادات البيانات
    data: {
      autoBackup: true,
      backupFrequency: 'weekly',
      dataCompression: true,
      offlineMode: false,
      syncAcrossDevices: true,
      storageOptimization: true,
    }
  });

  const tabs = [
    { id: 'profile', label: 'الملف الشخصي', icon: User },
    { id: 'privacy', label: 'الخصوصية', icon: Lock },
    { id: 'notifications', label: 'الإشعارات', icon: Bell },
    { id: 'security', label: 'الأمان', icon: Shield },
    { id: 'appearance', label: 'المظهر', icon: Palette },
    { id: 'data', label: 'البيانات', icon: Monitor },
  ];

  const handleSettingChange = (category: string, key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category as keyof typeof prev],
        [key]: value
      }
    }));
  };

  const handleSave = () => {
    // حفظ الإعدادات
    updateUser({
      name: settings.profile.name,
      bio: settings.profile.bio,
      location: settings.profile.location,
      website: settings.profile.website,
    });
    
    // حفظ الإعدادات في التخزين المحلي
    localStorage.setItem('user_settings', JSON.stringify(settings));
    
    // إظهار رسالة نجاح
    alert('تم حفظ الإعدادات بنجاح!');
  };

  const renderProfileSettings = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <h3 className="text-lg font-semibold mb-4 flex items-center">
          <User className="w-5 h-5 ml-2" />
          المعلومات الأساسية
        </h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">الاسم</label>
            <input
              type="text"
              value={settings.profile.name}
              onChange={(e) => handleSettingChange('profile', 'name', e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">النبذة الشخصية</label>
            <textarea
              value={settings.profile.bio}
              onChange={(e) => handleSettingChange('profile', 'bio', e.target.value)}
              rows={3}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="اكتب نبذة عن نفسك..."
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">الموقع</label>
              <input
                type="text"
                value={settings.profile.location}
                onChange={(e) => handleSettingChange('profile', 'location', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="المدينة، البلد"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">الموقع الإلكتروني</label>
              <input
                type="url"
                value={settings.profile.website}
                onChange={(e) => handleSettingChange('profile', 'website', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="https://example.com"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <h3 className="text-lg font-semibold mb-4 flex items-center">
          <Eye className="w-5 h-5 ml-2" />
          إعدادات العرض
        </h3>
        
        <div className="space-y-4">
          {[
            { key: 'showEmail', label: 'إظهار البريد الإلكتروني' },
            { key: 'showPhone', label: 'إظهار رقم الهاتف' },
            { key: 'showBirthday', label: 'إظهار تاريخ الميلاد' },
          ].map((item) => (
            <div key={item.key} className="flex items-center justify-between">
              <span className="text-gray-700">{item.label}</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.profile[item.key as keyof typeof settings.profile] as boolean}
                  onChange={(e) => handleSettingChange('profile', item.key, e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderPrivacySettings = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <h3 className="text-lg font-semibold mb-4 flex items-center">
          <Lock className="w-5 h-5 ml-2" />
          إعدادات الخصوصية
        </h3>
        
        <div className="space-y-4">
          {[
            { key: 'profileVisibility', label: 'من يمكنه رؤية ملفك الشخصي؟', options: ['public', 'friends', 'private'] },
            { key: 'postsVisibility', label: 'من يمكنه رؤية منشوراتك؟', options: ['public', 'friends', 'private'] },
            { key: 'friendsListVisibility', label: 'من يمكنه رؤية قائمة أصدقائك؟', options: ['public', 'friends', 'private'] },
            { key: 'messagePermissions', label: 'من يمكنه إرسال رسائل لك؟', options: ['everyone', 'friends', 'nobody'] },
            { key: 'tagPermissions', label: 'من يمكنه وسمك في المنشورات؟', options: ['everyone', 'friends', 'nobody'] },
            { key: 'storyVisibility', label: 'من يمكنه رؤية قصصك؟', options: ['public', 'friends', 'close_friends'] },
          ].map((item) => (
            <div key={item.key} className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">{item.label}</label>
              <select
                value={settings.privacy[item.key as keyof typeof settings.privacy] as string}
                onChange={(e) => handleSettingChange('privacy', item.key, e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {item.options.map((option) => (
                  <option key={option} value={option}>
                    {option === 'public' && 'عام'}
                    {option === 'friends' && 'الأصدقاء فقط'}
                    {option === 'private' && 'خاص'}
                    {option === 'everyone' && 'الجميع'}
                    {option === 'nobody' && 'لا أحد'}
                    {option === 'close_friends' && 'الأصدقاء المقربون'}
                  </option>
                ))}
              </select>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <h3 className="text-lg font-semibold mb-4">إعدادات إضافية</h3>
        
        <div className="space-y-4">
          {[
            { key: 'searchVisibility', label: 'السماح لمحركات البحث بفهرسة ملفك الشخصي' },
            { key: 'onlineStatus', label: 'إظهار حالة الاتصال للآخرين' },
          ].map((item) => (
            <div key={item.key} className="flex items-center justify-between">
              <span className="text-gray-700">{item.label}</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.privacy[item.key as keyof typeof settings.privacy] as boolean}
                  onChange={(e) => handleSettingChange('privacy', item.key, e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderNotificationSettings = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <h3 className="text-lg font-semibold mb-4 flex items-center">
          <Bell className="w-5 h-5 ml-2" />
          طرق الإشعار
        </h3>
        
        <div className="space-y-4">
          {[
            { key: 'emailNotifications', label: 'إشعارات البريد الإلكتروني', icon: '📧' },
            { key: 'pushNotifications', label: 'الإشعارات المنبثقة', icon: '🔔' },
            { key: 'soundEnabled', label: 'تفعيل الأصوات', icon: '🔊' },
          ].map((item) => (
            <div key={item.key} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <span className="text-xl">{item.icon}</span>
                <span className="text-gray-700">{item.label}</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.notifications[item.key as keyof typeof settings.notifications] as boolean}
                  onChange={(e) => handleSettingChange('notifications', item.key, e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <h3 className="text-lg font-semibold mb-4">أنواع الإشعارات</h3>
        
        <div className="space-y-4">
          {[
            { key: 'likes', label: 'الإعجابات', icon: Heart },
            { key: 'comments', label: 'التعليقات', icon: MessageCircle },
            { key: 'shares', label: 'المشاركات', icon: RefreshCw },
            { key: 'friendRequests', label: 'طلبات الصداقة', icon: Users },
            { key: 'messages', label: 'الرسائل', icon: MessageCircle },
            { key: 'mentions', label: 'الإشارات', icon: Bell },
            { key: 'birthdays', label: 'أعياد الميلاد', icon: Calendar },
            { key: 'events', label: 'الأحداث', icon: Calendar },
            { key: 'groupActivity', label: 'نشاط المجموعات', icon: Users },
          ].map((item) => (
            <div key={item.key} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <item.icon className="w-5 h-5 text-gray-600" />
                <span className="text-gray-700">{item.label}</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.notifications[item.key as keyof typeof settings.notifications] as boolean}
                  onChange={(e) => handleSettingChange('notifications', item.key, e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderSecuritySettings = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <h3 className="text-lg font-semibold mb-4 flex items-center">
          <Shield className="w-5 h-5 ml-2" />
          إعدادات الأمان
        </h3>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-gray-700 font-medium">المصادقة الثنائية</span>
              <p className="text-sm text-gray-500">طبقة حماية إضافية لحسابك</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.security.twoFactorAuth}
                onChange={(e) => handleSettingChange('security', 'twoFactorAuth', e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <span className="text-gray-700 font-medium">تنبيهات تسجيل الدخول</span>
              <p className="text-sm text-gray-500">إشعار عند تسجيل الدخول من جهاز جديد</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.security.loginAlerts}
                onChange={(e) => handleSettingChange('security', 'loginAlerts', e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">مهلة انتهاء الجلسة (بالدقائق)</label>
            <select
              value={settings.security.sessionTimeout}
              onChange={(e) => handleSettingChange('security', 'sessionTimeout', parseInt(e.target.value))}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value={15}>15 دقيقة</option>
              <option value={30}>30 دقيقة</option>
              <option value={60}>ساعة واحدة</option>
              <option value={120}>ساعتان</option>
              <option value={0}>بدون انتهاء</option>
            </select>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <h3 className="text-lg font-semibold mb-4">إدارة كلمة المرور</h3>
        
        <div className="space-y-4">
          <Button variant="outline" fullWidth>
            تغيير كلمة المرور
          </Button>
          
          <Button variant="outline" fullWidth>
            عرض سجل تسجيل الدخول
          </Button>
          
          <Button variant="outline" fullWidth>
            إنهاء جميع الجلسات النشطة
          </Button>
        </div>
      </div>
    </div>
  );

  const renderAppearanceSettings = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <h3 className="text-lg font-semibold mb-4 flex items-center">
          <Palette className="w-5 h-5 ml-2" />
          المظهر والسمة
        </h3>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">السمة</label>
            <div className="grid grid-cols-3 gap-3">
              {[
                { value: 'light', label: 'فاتح', icon: Sun },
                { value: 'dark', label: 'داكن', icon: Moon },
                { value: 'auto', label: 'تلقائي', icon: Monitor },
              ].map((theme) => (
                <button
                  key={theme.value}
                  onClick={() => handleSettingChange('appearance', 'theme', theme.value)}
                  className={`p-3 border rounded-lg flex flex-col items-center space-y-2 transition-colors ${
                    settings.appearance.theme === theme.value
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <theme.icon className="w-6 h-6" />
                  <span className="text-sm">{theme.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">اللغة</label>
            <select
              value={settings.appearance.language}
              onChange={(e) => handleSettingChange('appearance', 'language', e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="ar">العربية</option>
              <option value="en">English</option>
              <option value="fr">Français</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">حجم الخط</label>
            <select
              value={settings.appearance.fontSize}
              onChange={(e) => handleSettingChange('appearance', 'fontSize', e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="small">صغير</option>
              <option value="medium">متوسط</option>
              <option value="large">كبير</option>
            </select>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <h3 className="text-lg font-semibold mb-4">تفضيلات العرض</h3>
        
        <div className="space-y-4">
          {[
            { key: 'compactMode', label: 'الوضع المضغوط' },
            { key: 'animations', label: 'تفعيل الحركات' },
            { key: 'autoPlayVideos', label: 'تشغيل الفيديوهات تلقائياً' },
            { key: 'showOnlineStatus', label: 'إظهار حالة الاتصال' },
          ].map((item) => (
            <div key={item.key} className="flex items-center justify-between">
              <span className="text-gray-700">{item.label}</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.appearance[item.key as keyof typeof settings.appearance] as boolean}
                  onChange={(e) => handleSettingChange('appearance', item.key, e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderDataSettings = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <h3 className="text-lg font-semibold mb-4 flex items-center">
          <Monitor className="w-5 h-5 ml-2" />
          إدارة البيانات
        </h3>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-gray-700 font-medium">النسخ الاحتياطي التلقائي</span>
              <p className="text-sm text-gray-500">نسخ احتياطي منتظم لبياناتك</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.data.autoBackup}
                onChange={(e) => handleSettingChange('data', 'autoBackup', e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">تكرار النسخ الاحتياطي</label>
            <select
              value={settings.data.backupFrequency}
              onChange={(e) => handleSettingChange('data', 'backupFrequency', e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="daily">يومياً</option>
              <option value="weekly">أسبوعياً</option>
              <option value="monthly">شهرياً</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Button variant="outline" fullWidth>
              <Download className="w-4 h-4 ml-2" />
              تحميل البيانات
            </Button>
            <Button variant="outline" fullWidth>
              <Upload className="w-4 h-4 ml-2" />
              استيراد البيانات
            </Button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <h3 className="text-lg font-semibold mb-4">تحسين الأداء</h3>
        
        <div className="space-y-4">
          {[
            { key: 'dataCompression', label: 'ضغط البيانات' },
            { key: 'offlineMode', label: 'الوضع غير المتصل' },
            { key: 'syncAcrossDevices', label: 'المزامنة عبر الأجهزة' },
            { key: 'storageOptimization', label: 'تحسين التخزين' },
          ].map((item) => (
            <div key={item.key} className="flex items-center justify-between">
              <span className="text-gray-700">{item.label}</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.data[item.key as keyof typeof settings.data] as boolean}
                  onChange={(e) => handleSettingChange('data', item.key, e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-red-50 rounded-lg p-6 border border-red-200">
        <h3 className="text-lg font-semibold mb-4 text-red-800 flex items-center">
          <AlertTriangle className="w-5 h-5 ml-2" />
          منطقة الخطر
        </h3>
        
        <div className="space-y-4">
          <Button 
            variant="outline" 
            fullWidth
            className="border-red-300 text-red-700 hover:bg-red-50"
          >
            <Trash2 className="w-4 h-4 ml-2" />
            مسح جميع البيانات
          </Button>
          
          <Button 
            variant="danger" 
            fullWidth
            onClick={() => setShowDeleteModal(true)}
          >
            <Trash2 className="w-4 h-4 ml-2" />
            حذف الحساب نهائياً
          </Button>
        </div>
      </div>
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'profile': return renderProfileSettings();
      case 'privacy': return renderPrivacySettings();
      case 'notifications': return renderNotificationSettings();
      case 'security': return renderSecuritySettings();
      case 'appearance': return renderAppearanceSettings();
      case 'data': return renderDataSettings();
      default: return renderProfileSettings();
    }
  };

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-gray-50 rounded-lg w-full max-w-6xl h-[90vh] flex overflow-hidden"
        >
          {/* Sidebar */}
          <div className="w-80 bg-white border-l border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold">الإعدادات</h2>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center space-x-3 p-3 rounded-lg text-right transition-colors ${
                    activeTab === tab.id
                      ? 'bg-blue-50 text-blue-600 border border-blue-200'
                      : 'hover:bg-gray-100 text-gray-700'
                  }`}
                >
                  <tab.icon className="w-5 h-5" />
                  <span className="font-medium">{tab.label}</span>
                </button>
              ))}
            </div>

            <div className="mt-8 pt-6 border-t border-gray-200">
              <Button
                onClick={handleSave}
                variant="primary"
                fullWidth
                className="mb-3"
              >
                <Save className="w-4 h-4 ml-2" />
                حفظ التغييرات
              </Button>
              
              <Button
                onClick={onClose}
                variant="outline"
                fullWidth
              >
                إلغاء
              </Button>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {renderTabContent()}
          </div>
        </motion.div>
      </div>

      {/* Delete Account Modal */}
      <Modal
        isOpen={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        title="تأكيد حذف الحساب"
        size="md"
      >
        <div className="p-6">
          <div className="text-center mb-6">
            <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              هل أنت متأكد من حذف حسابك؟
            </h3>
            <p className="text-gray-600">
              هذا الإجراء لا يمكن التراجع عنه. سيتم حذف جميع بياناتك نهائياً.
            </p>
          </div>

          <div className="flex space-x-3">
            <Button
              variant="danger"
              fullWidth
              onClick={() => {
                // منطق حذف الحساب
                alert('تم حذف الحساب');
                setShowDeleteModal(false);
              }}
            >
              نعم، احذف حسابي
            </Button>
            <Button
              variant="outline"
              fullWidth
              onClick={() => setShowDeleteModal(false)}
            >
              إلغاء
            </Button>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default SettingsPage;