import React, { useState, useEffect, useRef } from 'react';
import { 
  Phone, Video, MoreHorizontal, Search, Smile, 
  Paperclip, Send, ArrowLeft, Info, Star 
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Avatar from '../ui/Avatar';
import Button from '../ui/Button';
import MessageBubble from './MessageBubble';
import MessageInput from './MessageInput';
import { User, Message } from '../../types';
import { formatTimeAgo } from '../../utils/dateUtils';

interface ChatWindowProps {
  user: User;
  currentUser: User;
  messages: Message[];
  onSendMessage: (content: string, attachments?: File[]) => void;
  onClose: () => void;
  isTyping?: boolean;
}

const ChatWindow: React.FC<ChatWindowProps> = ({
  user,
  currentUser,
  messages,
  onSendMessage,
  onClose,
  isTyping = false
}) => {
  const [showUserInfo, setShowUserInfo] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const groupedMessages = messages.reduce((groups: Message[][], message, index) => {
    if (index === 0 || messages[index - 1].from.id !== message.from.id) {
      groups.push([message]);
    } else {
      groups[groups.length - 1].push(message);
    }
    return groups;
  }, []);

  return (
    <div className="flex flex-col h-full bg-white rounded-lg shadow-lg border border-gray-200">
      {/* Chat Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gray-50 rounded-t-lg">
        <div className="flex items-center space-x-3">
          <Button variant="ghost" size="sm" onClick={onClose}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <Avatar
            fallback={user.name.charAt(0)}
            online={user.isOnline}
            size="md"
          />
          <div>
            <h3 className="font-semibold text-gray-900">{user.name}</h3>
            <p className="text-sm text-gray-500">
              {user.isOnline ? 'متصل الآن' : `آخر ظهور ${formatTimeAgo(user.lastSeen || '')}`}
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm">
            <Phone className="w-5 h-5 text-gray-600" />
          </Button>
          <Button variant="ghost" size="sm">
            <Video className="w-5 h-5 text-gray-600" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => setShowUserInfo(!showUserInfo)}
          >
            <Info className="w-5 h-5 text-gray-600" />
          </Button>
          <Button variant="ghost" size="sm">
            <MoreHorizontal className="w-5 h-5 text-gray-600" />
          </Button>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <AnimatePresence>
          {groupedMessages.map((group, groupIndex) => (
            <motion.div
              key={groupIndex}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-1"
            >
              {group.map((message, messageIndex) => (
                <MessageBubble
                  key={message.id}
                  message={message}
                  isOwn={message.from.id === currentUser.id}
                  showAvatar={messageIndex === group.length - 1}
                  showTimestamp={messageIndex === group.length - 1}
                />
              ))}
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Typing Indicator */}
        {isTyping && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center space-x-2"
          >
            <Avatar fallback={user.name.charAt(0)} size="sm" />
            <div className="bg-gray-200 rounded-2xl px-4 py-2">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              </div>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <MessageInput
        onSendMessage={onSendMessage}
        placeholder={`اكتب رسالة إلى ${user.name}...`}
      />

      {/* User Info Sidebar */}
      <AnimatePresence>
        {showUserInfo && (
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            className="absolute top-0 right-0 w-80 h-full bg-white border-l border-gray-200 rounded-r-lg shadow-lg z-10"
          >
            <div className="p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-900">معلومات المحادثة</h3>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setShowUserInfo(false)}
                >
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              </div>

              <div className="text-center mb-6">
                <Avatar
                  fallback={user.name.charAt(0)}
                  online={user.isOnline}
                  size="xl"
                  className="mx-auto mb-3"
                />
                <h4 className="font-semibold text-lg">{user.name}</h4>
                <p className="text-gray-500">{user.bio}</p>
              </div>

              <div className="space-y-3">
                <Button variant="outline" fullWidth>
                  <Star className="w-4 h-4" />
                  إضافة إلى المفضلة
                </Button>
                <Button variant="outline" fullWidth>
                  <Search className="w-4 h-4" />
                  البحث في المحادثة
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ChatWindow;