export const EMOTIONS = [
  { id: 'happy', label: 'سعيد', emoji: '😊', color: 'text-yellow-500' },
  { id: 'excited', label: 'متحمس', emoji: '🤩', color: 'text-orange-500' },
  { id: 'grateful', label: 'ممتن', emoji: '🙏', color: 'text-green-500' },
  { id: 'loved', label: 'محبوب', emoji: '🥰', color: 'text-pink-500' },
  { id: 'blessed', label: 'مبارك', emoji: '✨', color: 'text-purple-500' },
  { id: 'relaxed', label: 'مسترخي', emoji: '😌', color: 'text-blue-500' },
  { id: 'proud', label: 'فخور', emoji: '😎', color: 'text-indigo-500' },
  { id: 'thoughtful', label: 'متأمل', emoji: '🤔', color: 'text-gray-500' },
];

export const PRIVACY_OPTIONS = [
  { id: 'public', label: 'عام', icon: '🌍', description: 'يمكن لأي شخص رؤية هذا المنشور' },
  { id: 'friends', label: 'الأصدقاء', icon: '👥', description: 'الأصدقاء فقط' },
  { id: 'private', label: 'أنا فقط', icon: '🔒', description: 'أنت فقط' },
];

export const POST_TYPES = [
  { id: 'normal', label: 'منشور عادي', icon: null, color: 'text-gray-600' },
  { id: 'timed', label: 'رسالة زمنية', icon: 'Clock', color: 'text-green-600' },
  { id: 'anonymous', label: 'بوح مجهول', icon: 'MessageSquare', color: 'text-red-600' },
  { id: 'challenge', label: 'تحدي إبداعي', icon: 'Zap', color: 'text-purple-600' },
  { id: 'photo', label: 'صورة', icon: 'Image', color: 'text-blue-600' },
  { id: 'video', label: 'فيديو', icon: 'Video', color: 'text-indigo-600' },
];

export const NOTIFICATION_TYPES = {
  like: { icon: '❤️', color: 'text-red-500' },
  comment: { icon: '💬', color: 'text-blue-500' },
  share: { icon: '🔄', color: 'text-green-500' },
  friend_request: { icon: '👥', color: 'text-purple-500' },
  mention: { icon: '📢', color: 'text-orange-500' },
  birthday: { icon: '🎂', color: 'text-pink-500' },
};

export const SAMPLE_USERS = [
  {
    id: '1',
    name: 'أحمد محمد',
    email: 'ahmed@example.com',
    avatar: 'A',
    bio: 'مطور برمجيات ومحب للتقنية',
    location: 'الرياض، السعودية',
    joinDate: '2023-01-15',
    friendsCount: 234,
    followersCount: 567,
    followingCount: 123,
    isOnline: true,
  },
  {
    id: '2',
    name: 'فاطمة علي',
    email: 'fatima@example.com',
    avatar: 'F',
    bio: 'مصممة جرافيك وفنانة رقمية',
    location: 'دبي، الإمارات',
    joinDate: '2023-02-20',
    friendsCount: 456,
    followersCount: 789,
    followingCount: 234,
    isOnline: true,
  },
  {
    id: '3',
    name: 'محمد حسن',
    email: 'mohammed@example.com',
    avatar: 'M',
    bio: 'كاتب ومدون',
    location: 'القاهرة، مصر',
    joinDate: '2023-03-10',
    friendsCount: 345,
    followersCount: 678,
    followingCount: 156,
    isOnline: false,
    lastSeen: '2024-01-20T10:30:00Z',
  },
];