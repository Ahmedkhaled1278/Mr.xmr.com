import { formatDistanceToNow, format, isToday, isYesterday } from 'date-fns';
import { ar } from 'date-fns/locale';

export const formatTimeAgo = (timestamp: string): string => {
  const date = new Date(timestamp);
  const now = new Date();
  const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
  
  if (diffInMinutes < 1) return 'الآن';
  if (diffInMinutes < 60) return `منذ ${diffInMinutes} دقيقة`;
  if (diffInMinutes < 1440) return `منذ ${Math.floor(diffInMinutes / 60)} ساعة`;
  if (diffInMinutes < 10080) return `منذ ${Math.floor(diffInMinutes / 1440)} يوم`;
  
  return format(date, 'dd/MM/yyyy', { locale: ar });
};

export const formatPostTime = (timestamp: string): string => {
  const date = new Date(timestamp);
  
  if (isToday(date)) {
    return format(date, 'HH:mm');
  }
  
  if (isYesterday(date)) {
    return 'أمس';
  }
  
  return format(date, 'dd/MM', { locale: ar });
};

export const formatFullDate = (timestamp: string): string => {
  const date = new Date(timestamp);
  return format(date, 'EEEE، dd MMMM yyyy', { locale: ar });
};