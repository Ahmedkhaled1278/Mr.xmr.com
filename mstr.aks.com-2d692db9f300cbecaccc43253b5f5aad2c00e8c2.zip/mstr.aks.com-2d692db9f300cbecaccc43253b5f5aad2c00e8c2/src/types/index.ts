export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  coverPhoto?: string;
  bio?: string;
  location?: string;
  website?: string;
  joinDate: string;
  friendsCount: number;
  followersCount: number;
  followingCount: number;
  isOnline: boolean;
  lastSeen?: string;
}

export interface Post {
  id: string;
  author: User;
  content: string;
  type: 'normal' | 'timed' | 'anonymous' | 'challenge' | 'photo' | 'video' | 'link';
  timestamp: string;
  likes: number;
  comments: Comment[];
  shares: number;
  images?: string[];
  video?: string;
  link?: LinkPreview;
  location?: string;
  feeling?: string;
  taggedUsers?: User[];
  privacy: 'public' | 'friends' | 'private';
  isLiked?: boolean;
  isBookmarked?: boolean;
}

export interface Comment {
  id: string;
  author: User;
  content: string;
  timestamp: string;
  likes: number;
  replies?: Comment[];
  isLiked?: boolean;
}

export interface Story {
  id: string;
  author: User;
  content: string;
  type: 'photo' | 'video' | 'text';
  timestamp: string;
  expiresAt: string;
  viewers: User[];
  isViewed: boolean;
}

export interface LinkPreview {
  url: string;
  title: string;
  description: string;
  image: string;
  domain: string;
}

export interface Notification {
  id: string;
  type: 'like' | 'comment' | 'share' | 'friend_request' | 'mention' | 'birthday';
  from: User;
  post?: Post;
  message: string;
  timestamp: string;
  isRead: boolean;
}

export interface Message {
  id: string;
  from: User;
  to: User;
  content: string;
  timestamp: string;
  isRead: boolean;
  type: 'text' | 'image' | 'video' | 'audio' | 'file';
  attachments?: string[];
}

export interface Group {
  id: string;
  name: string;
  description: string;
  avatar: string;
  coverPhoto: string;
  members: User[];
  admins: User[];
  posts: Post[];
  privacy: 'public' | 'private' | 'secret';
  createdAt: string;
}

export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  organizer: User;
  attendees: User[];
  interested: User[];
  coverPhoto: string;
  privacy: 'public' | 'private';
}