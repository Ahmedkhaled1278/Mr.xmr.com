import CryptoJS from 'crypto-js';

export class SecurityManager {
  private static instance: SecurityManager;
  private encryptionKey: string;
  private rateLimitMap: Map<string, { count: number; resetTime: number }> = new Map();
  private blockedIPs: Set<string> = new Set();
  private suspiciousActivities: Map<string, number> = new Map();

  private constructor() {
    this.encryptionKey = this.generateSecureKey();
    this.initializeSecurityHeaders();
    this.setupCSPPolicy();
    this.initializeRateLimiting();
  }

  public static getInstance(): SecurityManager {
    if (!SecurityManager.instance) {
      SecurityManager.instance = new SecurityManager();
    }
    return SecurityManager.instance;
  }

  // تشفير البيانات الحساسة
  public encryptData(data: string): string {
    try {
      return CryptoJS.AES.encrypt(data, this.encryptionKey).toString();
    } catch (error) {
      console.error('Encryption failed:', error);
      throw new Error('فشل في تشفير البيانات');
    }
  }

  // فك تشفير البيانات
  public decryptData(encryptedData: string): string {
    try {
      const bytes = CryptoJS.AES.decrypt(encryptedData, this.encryptionKey);
      return bytes.toString(CryptoJS.enc.Utf8);
    } catch (error) {
      console.error('Decryption failed:', error);
      throw new Error('فشل في فك تشفير البيانات');
    }
  }

  // توليد مفتاح تشفير آمن
  private generateSecureKey(): string {
    const array = new Uint8Array(32);
    crypto.getRandomValues(array);
    return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
  }

  // حماية من XSS
  public sanitizeInput(input: string): string {
    const div = document.createElement('div');
    div.textContent = input;
    return div.innerHTML
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#x27;')
      .replace(/\//g, '&#x2F;');
  }

  // حماية من SQL Injection
  public validateInput(input: string, type: 'email' | 'text' | 'number' | 'password'): boolean {
    const patterns = {
      email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
      text: /^[a-zA-Z0-9\u0600-\u06FF\s\-_.,!?]+$/,
      number: /^\d+$/,
      password: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/
    };

    // فحص الأنماط المشبوهة
    const suspiciousPatterns = [
      /(\bSELECT\b|\bINSERT\b|\bUPDATE\b|\bDELETE\b|\bDROP\b|\bCREATE\b)/i,
      /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
      /javascript:/i,
      /on\w+\s*=/i,
      /eval\s*\(/i,
      /expression\s*\(/i
    ];

    for (const pattern of suspiciousPatterns) {
      if (pattern.test(input)) {
        this.logSuspiciousActivity('malicious_input', input);
        return false;
      }
    }

    return patterns[type]?.test(input) ?? false;
  }

  // Rate Limiting - حماية من DDoS
  public checkRateLimit(identifier: string, maxRequests: number = 100, windowMs: number = 60000): boolean {
    const now = Date.now();
    const userLimit = this.rateLimitMap.get(identifier);

    if (!userLimit || now > userLimit.resetTime) {
      this.rateLimitMap.set(identifier, {
        count: 1,
        resetTime: now + windowMs
      });
      return true;
    }

    if (userLimit.count >= maxRequests) {
      this.logSuspiciousActivity('rate_limit_exceeded', identifier);
      this.blockedIPs.add(identifier);
      return false;
    }

    userLimit.count++;
    return true;
  }

  // فحص IP المحظورة
  public isIPBlocked(ip: string): boolean {
    return this.blockedIPs.has(ip);
  }

  // حماية من CSRF
  public generateCSRFToken(): string {
    const array = new Uint8Array(16);
    crypto.getRandomValues(array);
    const token = Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
    sessionStorage.setItem('csrf_token', token);
    return token;
  }

  public validateCSRFToken(token: string): boolean {
    const storedToken = sessionStorage.getItem('csrf_token');
    return storedToken === token;
  }

  // إعداد Content Security Policy
  private setupCSPPolicy(): void {
    const csp = [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com",
      "img-src 'self' data: https:",
      "connect-src 'self' wss: https:",
      "frame-ancestors 'none'",
      "base-uri 'self'",
      "form-action 'self'"
    ].join('; ');

    const meta = document.createElement('meta');
    meta.httpEquiv = 'Content-Security-Policy';
    meta.content = csp;
    document.head.appendChild(meta);
  }

  // إعداد Security Headers
  private initializeSecurityHeaders(): void {
    // X-Frame-Options
    const frameOptions = document.createElement('meta');
    frameOptions.httpEquiv = 'X-Frame-Options';
    frameOptions.content = 'DENY';
    document.head.appendChild(frameOptions);

    // X-Content-Type-Options
    const contentType = document.createElement('meta');
    contentType.httpEquiv = 'X-Content-Type-Options';
    contentType.content = 'nosniff';
    document.head.appendChild(contentType);

    // Referrer Policy
    const referrer = document.createElement('meta');
    referrer.name = 'referrer';
    referrer.content = 'strict-origin-when-cross-origin';
    document.head.appendChild(referrer);
  }

  // تسجيل الأنشطة المشبوهة
  private logSuspiciousActivity(type: string, details: string): void {
    const key = `${type}_${details}`;
    const count = this.suspiciousActivities.get(key) || 0;
    this.suspiciousActivities.set(key, count + 1);

    // إرسال تنبيه إذا تكررت المحاولات
    if (count > 5) {
      this.sendSecurityAlert(type, details, count);
    }

    console.warn(`نشاط مشبوه: ${type}`, { details, count: count + 1 });
  }

  // إرسال تنبيهات الأمان
  private sendSecurityAlert(type: string, details: string, count: number): void {
    // هنا يمكن إرسال تنبيه للمشرفين
    console.error(`تنبيه أمني: ${type} تكرر ${count} مرات`, details);
  }

  // تنظيف البيانات المؤقتة
  private initializeRateLimiting(): void {
    setInterval(() => {
      const now = Date.now();
      for (const [key, value] of this.rateLimitMap.entries()) {
        if (now > value.resetTime) {
          this.rateLimitMap.delete(key);
        }
      }
    }, 60000); // تنظيف كل دقيقة
  }

  // فحص سلامة الجلسة
  public validateSession(): boolean {
    const sessionData = sessionStorage.getItem('user_session');
    if (!sessionData) return false;

    try {
      const session = JSON.parse(sessionData);
      const now = Date.now();
      
      // فحص انتهاء صلاحية الجلسة
      if (session.expiresAt && now > session.expiresAt) {
        this.clearSession();
        return false;
      }

      // فحص تغيير User Agent
      if (session.userAgent && session.userAgent !== navigator.userAgent) {
        this.clearSession();
        return false;
      }

      return true;
    } catch (error) {
      this.clearSession();
      return false;
    }
  }

  // مسح الجلسة
  public clearSession(): void {
    sessionStorage.clear();
    localStorage.removeItem('user');
  }

  // حماية من Clickjacking
  public preventClickjacking(): void {
    if (window.top !== window.self) {
      window.top!.location = window.self.location;
    }
  }

  // فحص التلاعب بـ DOM
  public monitorDOMChanges(): void {
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === 'childList') {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              const element = node as Element;
              
              // فحص السكريبت المشبوهة
              if (element.tagName === 'SCRIPT') {
                const src = element.getAttribute('src');
                const content = element.textContent;
                
                if (src && !this.isAllowedScript(src)) {
                  element.remove();
                  this.logSuspiciousActivity('unauthorized_script', src);
                }
                
                if (content && this.containsMaliciousCode(content)) {
                  element.remove();
                  this.logSuspiciousActivity('malicious_script', content.substring(0, 100));
                }
              }
            }
          });
        }
      });
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  // فحص السكريبت المسموحة
  private isAllowedScript(src: string): boolean {
    const allowedDomains = [
      'fonts.googleapis.com',
      'fonts.gstatic.com',
      window.location.origin
    ];

    return allowedDomains.some(domain => src.includes(domain));
  }

  // فحص الكود الضار
  private containsMaliciousCode(code: string): boolean {
    const maliciousPatterns = [
      /eval\s*\(/i,
      /document\.write/i,
      /innerHTML\s*=/i,
      /outerHTML\s*=/i,
      /javascript:/i,
      /vbscript:/i,
      /onload\s*=/i,
      /onerror\s*=/i
    ];

    return maliciousPatterns.some(pattern => pattern.test(code));
  }
}

export default SecurityManager;