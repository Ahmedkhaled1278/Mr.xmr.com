import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import './index.css'

// تحسين الأداء
const root = ReactDOM.createRoot(document.getElementById('root')!);

// إزالة StrictMode في الإنتاج لتحسين الأداء
root.render(<App />);

// تحميل الخطوط مسبقاً
const preloadFonts = () => {
  const link = document.createElement('link');
  link.rel = 'preload';
  link.href = 'https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;500;600;700;800&display=swap';
  link.as = 'style';
  document.head.appendChild(link);
};

preloadFonts();