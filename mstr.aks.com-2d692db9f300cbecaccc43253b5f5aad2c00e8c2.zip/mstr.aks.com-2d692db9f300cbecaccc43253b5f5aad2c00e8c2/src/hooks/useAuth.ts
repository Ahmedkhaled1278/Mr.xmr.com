import { useState, useEffect, createContext, useContext } from 'react';
import { User } from '../types';
import { useLocalStorage } from './useLocalStorage';

interface AuthContextType {
  user: User | null;
  login: (userData: Partial<User>) => Promise<void>;
  logout: () => void;
  updateUser: (userData: Partial<User>) => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const useAuthProvider = () => {
  const [user, setUser] = useLocalStorage<User | null>('user', null);
  const [isLoading, setIsLoading] = useState(false);

  const login = async (userData: Partial<User>) => {
    setIsLoading(true);
    try {
      // محاكاة تسجيل دخول سريع
      await new Promise(resolve => setTimeout(resolve, 300));
      
      const newUser: User = {
        id: Date.now().toString(),
        name: userData.name || 'مستخدم جديد',
        email: userData.email || '',
        joinDate: new Date().toISOString(),
        friendsCount: 0,
        followersCount: 0,
        followingCount: 0,
        isOnline: true,
        ...userData,
      };
      
      setUser(newUser);
    } catch (error) {
      console.error('Login error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
  };

  const updateUser = (userData: Partial<User>) => {
    if (user) {
      setUser({ ...user, ...userData });
    }
  };

  return {
    user,
    login,
    logout,
    updateUser,
    isLoading,
  };
};

export { AuthContext };