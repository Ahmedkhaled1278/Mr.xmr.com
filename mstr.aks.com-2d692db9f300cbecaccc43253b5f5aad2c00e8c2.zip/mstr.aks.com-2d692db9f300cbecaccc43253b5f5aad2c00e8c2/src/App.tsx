import React, { Suspense, lazy } from 'react';
import { AuthContext, useAuthProvider } from './hooks/useAuth';
import LoadingSpinner from './components/ui/LoadingSpinner';

// تحميل المكونات بشكل تدريجي
const AuthPage = lazy(() => import('./components/auth/AuthPage'));
const Layout = lazy(() => import('./components/layout/Layout'));
const MainFeed = lazy(() => import('./components/feed/MainFeed'));

function App() {
  const auth = useAuthProvider();

  if (!auth.user) {
    return (
      <AuthContext.Provider value={auth}>
        <Suspense fallback={<LoadingSpinner />}>
          <AuthPage />
        </Suspense>
      </AuthContext.Provider>
    );
  }

  return (
    <AuthContext.Provider value={auth}>
      <Suspense fallback={<LoadingSpinner />}>
        <Layout user={auth.user} onLogout={auth.logout}>
          <MainFeed user={auth.user} />
        </Layout>
      </Suspense>
    </AuthContext.Provider>
  );
}

export default App;