mstr.aks.com
